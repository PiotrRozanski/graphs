// Todo zlikwidowac po zmianie na GRaphModel
export class Edge {
  public id: number;
  public weight: number;


  constructor(id: number, weight: number) {
    this.id = id;
    this.weight = weight;
  }
}
