export class TreeNode {
  label: number;
  data: number;

  constructor(label: number, data: number) {
    this.label = label;
    this.data = data;
  }
}
